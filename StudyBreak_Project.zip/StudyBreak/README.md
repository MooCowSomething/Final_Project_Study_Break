# Study Break — Interactive Student Desk

A single-file C++ OpenGL final-project starter. No textures, images, audio, or other runtime assets are needed. Libraries are external dependencies and are not bundled. Review and personalize the scene as a group before submitting.

## Requirements

- C++11 compiler (Visual Studio/MSVC or MinGW-w64 on Windows).
- FreeGLUT, not the original GLUT, for the mouse wheel, full-screen toggle, and clean exit.
- GLEW.
- Desktop OpenGL 2.1 or a newer compatibility context. This code intentionally uses the course-style fixed-function matrix stack and client vertex arrays; it will not run in a core-only context.
- Match the architecture of your compiler, libraries, and DLLs (all x64 or all x86). Do not mix MSVC and MinGW library builds.

## Windows: use an existing OpenGL class project

1. Create a copy of your working C++ OpenGL project.
2. Remove its old main source from the build, and add StudyBreak.cpp. There must be only one main function.
3. Configure the FreeGLUT and GLEW include directories (the parent folders containing GL/freeglut.h and GL/glew.h).
4. Configure the library directories for your compiler and architecture.
5. For MSVC dynamic linking, add opengl32.lib, freeglut.lib, and glew32.lib to Linker > Input > Additional Dependencies. Use the actual names provided by your library distribution.
6. Put the matching FreeGLUT and GLEW runtime DLLs next to the generated EXE, or ensure they are on PATH. OpenGL32 is supplied by Windows.
7. Build and run. The app starts full screen. Press Esc to close it.

For MinGW, with include/lib paths already configured, a typical command is:

    g++ -std=c++11 StudyBreak.cpp -o StudyBreak.exe -lfreeglut -lglew32 -lopengl32

For static GLEW, define GLEW_STATIC and link its static library instead. Static FreeGLUT has separate settings; dynamic libraries are the simpler starting point.

## CMake alternative

With the dependencies installed and discoverable by CMake:

    cmake -S . -B build
    cmake --build build --config Release

If using an existing package-manager toolchain, supply its CMAKE_TOOLCHAIN_FILE during configuration. On Windows, run the EXE from the build output directory, with required DLLs available.

## Linux alternative

With FreeGLUT and GLEW development packages installed and a graphical desktop:

    g++ -std=c++11 StudyBreak.cpp -o StudyBreak -lGLEW -lglut -lGL
    ./StudyBreak

## Controls

| Input | Result |
| --- | --- |
| No input | Car automatically moves along the desk, then returns to the left |
| Left click anywhere in the window | Fan blades rotate 30 degrees |
| Vertical mouse wheel | Sticky note changes size, limited to 60–160% |
| Space | Pause/resume car |
| R | Reset positions, angle, scale, and resume car |
| F | Toggle full-screen/windowed mode |
| Esc | Exit |

## Requirement mapping and explanation

1. Full screen: glutFullScreen in main.
2. Three major objects: toy car, electric fan, sticky note.
3. Primitives: GL_TRIANGLES (rectangles/car/blades), GL_TRIANGLE_FAN (circles), GL_LINES (details/cage).
4. Colors: red car, blue fan, yellow note.
5. CPU Vertex Array: drawNote passes noteVertices to glVertexPointer with GL_ARRAY_BUFFER bound to zero. GPU VBO: initializeVBO uploads car vertices once; drawCar binds that buffer and calls glDrawArrays. A VAO is not being substituted for the CPU array.
6. Translation: timer updates carX; drawCar uses glTranslatef. Rotation: mouse updates fanAngle; drawFan uses glRotatef around the fan center. Scaling: wheel updates noteScale; drawNote uses glScalef around its center.
7. Independent transforms: glPushMatrix/glPopMatrix contain each object's changes. A nested scope rotates fan blades without rotating its base or cage.
8. Compile and verify on your group's computer using the checklist below.

The VBO uses GL_STATIC_DRAW because the uploaded geometry is unchanged; a transformation moves the car. Animated objects do not require GL_DYNAMIC_DRAW when vertex data itself stays constant. Double buffering reduces flicker. The timer requests an update about every 16 ms, and elapsed time determines car movement speed. Letterboxing preserves proportions on different screens.

## Manual verification before submission

- Build without compiler/linker errors.
- Confirm startup is full screen and the instructions are visible.
- Watch the car travel and wrap to the left; the other objects should stay still.
- Pause the car. Click once: only the blades rotate 30 degrees. Click 12 times total to complete a revolution.
- Scroll up and down. Only the sticky note and its contents resize. Test both size limits.
- Press R: car returns to its starting point and resumes; fan angle resets; note returns to 100%.
- Press F, resize the window, and press F again. Circles should remain circular.
- Press Esc, and separately test closing the window in windowed mode.
- Collect your own running screenshots and describe the actual results.

## Validation status

This source was prepared in an environment without the FreeGLUT/GLEW development packages or a graphical display. A real OpenGL build and interactive run have NOT been verified here. The final build and mouse/full-screen checks must be completed on your computer. No prebuilt EXE is included.

## Simple presentation explanation

“Our scene shows a student's desk during a study break. The car demonstrates automatic translation. Clicking rotates the electric fan's blades. Scrolling changes the sticky note's size. We use a CPU vertex array for the note and a VBO for the car. Each object has its own saved transformation state, so changing one does not change the others.”

## Suggested group responsibilities

- Member 1: background, desk, colors, and layout.
- Member 2: car vertices, VBO, and timed translation.
- Member 3: fan rotation, sticky-note vertex array, and scaling.
- Member 4 (if available): integration, testing, screenshots, and presentation.

## AI-use record starter

Prompt: “Can you assist me on making Study Break — Interactive Student Desk?”
Assistance: initial C++ source, scene design, build guide, and requirement mapping.
Complete this record with your group's actual changes, tests, and explanations. Do not claim unperformed tests. Follow your instructor's AI-assisted submission rules.

## Official references

- FreeGLUT API: https://freeglut.sourceforge.net/docs/api.php
- GLEW initialization: https://glew.sourceforge.net/basic.html
